module.exports = {
  content: ['./*.html'],
  theme: {
    extend: {
      width: {
        500: '500px',
        600: '600px',
      },
    },
  },
  plugins: [],
};
